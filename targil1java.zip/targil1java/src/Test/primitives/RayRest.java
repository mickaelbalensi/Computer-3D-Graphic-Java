package primitives;

public class RayRest {

}
